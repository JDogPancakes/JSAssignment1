
function addListItem(){//Adds a list item
  var listItem = document.createElement("li")
  var listItemValue = document.getElementById("listAddBox").value;
  var textNode = document.createTextNode(listItemValue); //Prepare the objects with variables
  listItem.id = listItemValue;
  listItem.appendChild(textNode);//Appends the item to the list
  document.getElementById("itemList").appendChild(listItem);
  var checkbox = document.createElement("input");//Adds the items checkbox
  checkbox.type = "checkbox";
  checkbox.id = listItemValue+"1";
  checkbox.onclick = function(e){//Gives it the function when its clicked
    checked(e);
  }
  listItem.appendChild(checkbox);//Adds the checkbox
}
function checked(e){
  //This does the work needed when checkbox is clicked
  var checkboxid =document.getElementById((""+e.target.id).substring(0, (""+e.target.id).length-1));
  checkboxid.classList.add("checked");//First it adds the styling to a checked box
  var listArray = document.getElementsByTagName("li");
  document.getElementById("itemList").appendChild(checkboxid);
  listArray[checkboxid].parentNode.removeChild(listArray[checkboxid]);//Then it creates and array and moves it to the bottom of the list
}
function removeListItem(){//This makes it into array and removes said item
  var listArray= document.getElementsByTagName("li")
  var removeTextValue = document.getElementById("listRemoveBox").value;
  var itemToRemove = document.getElementById(removeTextValue);
  listArray[removeTextValue].parentNode.removeChild(listArray[removeTextValue]);

}
